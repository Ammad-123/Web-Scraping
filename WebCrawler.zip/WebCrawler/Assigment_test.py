
import requests,re
from bs4 import BeautifulSoup
import csv,random

def crawl_and_extract_data(base_url):
    # Send an HTTP request to the target URL
    headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                }

    response = requests.get(base_url,headers=headers)

   
    if response.status_code == 200:
        # Parse the HTML content
        soup = BeautifulSoup(response.text, 'html.parser')

        # Traverse the nested elements to find the article with the specified id
        article = None

        # Start from the outermost div and navigate through the hierarchy
        wrapper_div = soup.find('div', class_='wrapper')
        if wrapper_div:
            print("Found wrapper_div")
            # print(f"Content of wrapper_div: {wrapper_div.text.strip()}")

        # Find the <div> with class 'wrapperContent' within 'wrapper_div'
            wrapper_content_div = wrapper_div.find('div', class_='wrapperContent')
            if wrapper_content_div:
                print("Found wrapper_content_div")
                # print(f"Content of wrapper_content_div: {wrapper_content_div.text.strip()}")

                # Find the <div> with class 'main-group' within 'wrapper_content_div'
                main_group_div = wrapper_content_div.find('div', class_='main-group')
                if main_group_div:
                    print("Found main_group_div")
                    # print(f"Content of main_group_div: {main_group_div.text.strip()}")

                    # Find the <div> with class 'main container' and id 'main_content' within 'main_group_div'
                    main_container_div = main_group_div.find('div', class_='main container', id='main_content')
                    if main_container_div:
                        print("Found main_container_div")
                        data_list = []
                        services_content_div = main_container_div.find('div', class_='services-content')
                        if services_content_div:
                            print("Found services_content_div")
                            data_list.append(services_content_div.text.strip())
                            print(len(data_list))
                            print(data_list)
                            # Define regular expressions to extract the required data
                            patterns = {
                                'Type': r'Type:(.*?)Notice type:',
                                'Notice type': r'Notice type:(.*?)Earliest publish date:',
                                'Earliest publish date': r'Earliest publish date:(.*?)Edition:',
                                'Edition': r'Edition:(.*?)Notice ID:',
                                'Notice ID': r'Notice ID:(.*?)Company number:',
                                'Company number' : r'\(Company Number (\d+)\)',
                                'Notice timeline': r'Notice timeline for company number(.*?)Notice code:',
                                'Notice code': r'Notice code:(.*?)About Resolutions for Winding Up notices',
                                'Location details': r'Location details:(.*?)Other relevant information:',
                            }
                            
                            notice_id_set = set()
                            if data_list:
                                # Extract 'Publication Date'
                                extracted_data = {}
                                publication_date_match = re.search(patterns['Earliest publish date'], data_list[0], re.DOTALL)
                                if publication_date_match:
                                    extracted_data['Publication Date'] = publication_date_match.group(1).strip()

                                # Extract 'Notice ID'
                                notice_id_match = re.search(patterns['Notice ID'], data_list[0], re.DOTALL)
                                if notice_id_match:
                                    notice_id = notice_id_match.group(1).strip()

                                    # Check if the Notice ID is not in the set
                                    if notice_id not in notice_id_set:
                                        notice_id_set.add(notice_id)

                                        # Iterate through patterns and extract data
                                        for key, pattern in patterns.items():
                                            match = re.search(pattern, data_list[0], re.DOTALL)
                                            if match:
                                                extracted_data[key] = match.group(1).strip()

                                        # Print the extracted data
                                        for key, value in extracted_data.items():
                                            print(f'{key}: {value}')

                                        csv_file_path = 'extracted_data.csv'
                                        with open(csv_file_path, 'a', newline='') as csv_file:
                                            csv_writer = csv.DictWriter(csv_file, fieldnames=extracted_data.keys())
                                            if csv_file.tell() == 0:
                                                csv_writer.writeheader()
                                            csv_writer.writerow(extracted_data)

                                        print(f'Data has been written to {csv_file_path}')
                                    else:
                                        print(f'Duplicate entry found for Notice ID: {notice_id}')
                            else:
                                print("data_list is empty.")

if __name__ == "__main__":
    target_url = """ https://www.thegazette.co.uk/all-notices/notice?text=&categorycode-all=all&noticetype
                    s=&location-postcode-1=&location-distance-1=1&location-local-authority-1=&numberOf
                    LocationSearches=1&start-publish-date=&end-publish-date=&edition=&london-issue=&e
                    dinburgh-issue=&belfast-issue=&sort-by=&results-page-size=50
                """

    # Call the function with the target URL
    crawl_and_extract_data(target_url)
